``django-crequest`` was originally created in middle 2012 at home, the bedroom
division of the Alireza's place somewhere on planet earth maybe.

The PRIMARY AUTHORS are (and/or have been):

* Alireza Savand <alireza.savand@gmail.com>
* François‎

And here is an inevitably incomplete list of MUCH-APPRECIATED CONTRIBUTORS --
people who have submitted patches, reported bugs, added translations, helped
answer newbie questions, and generally made ``django-crequest`` that much better:

* Alireza Savand <alireza.savand@gmail.com>
* Richard Royal <richard.royal@coxinc.com>
* Robert Rollins <rrollins@caltech.edu>
* Alan Sergeant @asergeant01
* Kouichi Nishizawa @koty

A big THANK YOU goes to:

* François‎ for convincing Alireza to start the project.
* Guido van Rossum for creating Python.
