2018.5.11
=========
----

* Fixed #9: Error when installing on Python 2.


2018.5.1
========
----

* Fixed #7: process_exception() should not delete the request when using MIDDLEWARE.
* Feature #5: Fix encoding error in the setup.py file.


2016.3.16
=========
----

* Add Django 1.10 support.


2014.9.19
=========
----

* Feature: Add packaging files: ``AUTHORS.rst``, ``ChangeLog.rst``, ``MANIFEST.in``.
* Feature: Typos and fix ``README.rst`` spellings and remove unneeded files.
* Feature: Enhance documentation.
* Feature: Change release version numbering to date based.
* Feature: Add ``Python 2``, ``Python 3``, ``PyPy`` support.


1.0
===

----

* Initial version and stable for production.


